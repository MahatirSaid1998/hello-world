import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'vue-nav-tabs/themes/vue-tabs.css';
import 'vue-good-table/dist/vue-good-table.css';
export interface IBbUlmPlayerWebPartProps {
    description: string;
}
export default class BbUlmPlayerWebPart extends BaseClientSideWebPart<IBbUlmPlayerWebPartProps> {
    render(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
