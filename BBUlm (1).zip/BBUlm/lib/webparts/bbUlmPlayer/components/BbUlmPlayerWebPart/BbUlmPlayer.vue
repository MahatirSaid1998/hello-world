<template>
  <div>
    <modals-container/>
    <component :is="selectedComponent"></component>
  </div>
</template>
  
<script>
import { mapMutations } from "vuex";
import * as $ from "jquery";
import Teams from "./Teams/Teams.vue";
import TeamInfos from "./Teams/TeamDetails/TeamInfos.vue";
import PlayerTabs from "./Players/PlayerTabs.vue";

export default {
  components: {
    appTeams: Teams,
    appTeamInfo: TeamInfos,
    appPlayerTabs: PlayerTabs
  },
  data: function() {
    return {
      showTabsFlag: false,
      selectedComponent: "appTeams"
    };
  },
  created: function() {
    document.getElementById("DeltaPlaceHolderPageTitleInTitleArea").innerHTML = "Team/Spielerverwaltung";
    var $this = this;
    //watch selected team
    this.$store.watch(
      function(state) {
        return $this.$store.state.selectedTeamID; // could also put a Getter here
      },
      function(newValue, oldValue) {
        $this.selectedComponent = $this.$store.state.selectedComp;
        //something changed do something
        //$this.selectedPlayerInfo(newValue);

        //console.log(oldValue);
        //console.log(newValue);
      },
      //Optional Deep if you need it
      {
        deep: true
      }
    );

    this.$store.watch(
      function(state) {
        return $this.$store.state.selectedComp; // could also put a Getter here
      },
      function(newValue, oldValue) {
        $this.selectedComponent = $this.$store.state.selectedComp;
        //something changed do something
        //$this.selectedPlayerInfo(newValue);

        //console.log(oldValue);
        //console.log(newValue);
      },
      //Optional Deep if you need it
      {
        deep: true
      }
    );
  },
  methods: {
    showTabs: function(flag) {
      this.showTabsFlag = flag;
    }
  }
};
</script>

<style>
.content_3f74e132 {
  padding: 0px;
}
</style>
