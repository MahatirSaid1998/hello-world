<template>
  <tr>
    <td style="padding:5px" class="text-center">{{this.rowCounter}}</td>

    <td style="padding:5px" class="text-left">
      <a href="#" @click="playerIsSelected(player.ID)">{{this.player.Name}}</a>
    </td>
    <td style="padding:5px" class="text-center">{{this.player.Position}}</td>
    <td style="padding:5px" class="text-center">{{this.player.Birthday}}</td>
    <td style="padding:5px" class="text-center">{{this.player.Nationality}}</td>
    <td style="padding:5px" class="text-center">{{this.player.Telephone}}</td>
  </tr>
</template>

<script>
export default {
  props: {
    player: {
      type: Object
    },
    index: {
      type: Number
    }
  },
  computed: {
    rowCounter: function() {
      this.index++;
      return this.index;
    }
  },
  data: function() {
    return {
      counter: 0
    };
  },
  methods: {
    playerIsSelected: function(playerID) {
      this.$store.state.selectedComp = "appPlayerTabs"; // "appPlayers";
      // this.$store.state.selectedPlayerID = playerID// "appPlayers";
      this.$store.state.selectedPlayer = this.player;
    }
  }
};
</script>

<style>
</style>
