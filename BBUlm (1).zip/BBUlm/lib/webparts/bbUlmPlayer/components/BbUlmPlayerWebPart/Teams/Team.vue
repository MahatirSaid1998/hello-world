<template>
  <tr>
    <td style="padding:5px">{{this.rowCounter}}</td>
    <td style="padding:5px">
      <a href="#" @click="teamIsSelected">{{this.team.TeamName}}</a>
    </td>
    <td style="padding:5px">{{this.team.Coach}}</td>
    <td style="padding:5px">{{this.team.CoachAssistant}}</td>
  </tr>
</template>


<script>
export default {
  props: {
    team: {
      type: Object
    },
    index: {
      type: Number
    }
  },
  computed: {
    rowCounter: function() {
      this.index++;
      return this.index;
    }
  },
  data: function() {
    return {
      counter: 0
    };
  },
  methods: {
        teamIsSelected: function() {
          this.$store.state.selectedTeam= this.team
          this.$store.state.selectedComp='appTeamInfo'; 
          //this.$emit('teamIsSelected', teamID)
        }
    }
};
</script>

<style>
</style>
