<template>
  <div>
    <h2>Teams</h2>

    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Team name</th>
          <th scope="col">Coach</th>
          <th scope="col">Coach Assistant</th>
        </tr>
      </thead>
      <tbody>
        <app-team
          v-for="(team, index) in teams"
          :team="team"
          :index="index++"
          @teamIsSelected="onclickTeam"
        ></app-team>
      </tbody>
    </table>
  </div>
</template>

<script>
import * as $ from "jquery";
import Team from "./Team.vue";
export default {
  components: {
    appTeam: Team
  },
  data: function() {
    return {
      teams: []
    };
  },
  created: function() {
    this.loadTeams();
  },
  methods: {
    loadTeams: function() {
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Team";
      var select =
        "$select=id,TeamName,Coach,CoachTel,CoachAddress,CoachAssistant,CoachAssistTel,CoachAssistAddress,TeamName/TeamName";
      var expand = "&$expand=TeamName";
      // var filter = "&$filter=PlayerNameId eq '" + playerID + "'";
      baseUrl += "GetByTitle('" + listName + "')/items?" + select + expand;
      +select + expand; // + filter;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.teamsData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    teamsData: function(data) {
      this.teams = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        $this.teams.push({
          id: data[i].ID,
          TeamName: data[i].TeamName.TeamName,
          Coach: data[i].Coach,
          CoachTel: data[i].CoachTel,
          CoachAddress: data[i].CoachAddress,
          CoachAssistant: data[i].CoachAssistant,
          CoachAssistTel: data[i].CoachAssistTel,
          CoachAssistAddress: data[i].CoachAssistAddress
        });
      }
    }
  }
};
</script>

<style>
</style>
