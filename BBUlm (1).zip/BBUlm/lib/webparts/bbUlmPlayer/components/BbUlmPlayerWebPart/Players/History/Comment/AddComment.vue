<template>
  <div class="container mt-2">
    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Date
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <date-picker
          v-model="commentData.customDate"
          :lang="lang"
          type="datetime"
          format="DD.MM.YYYY HH:mm"
          :minute-step="15"
          confirm
        ></date-picker>
      </div>
    </div>
    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Comment
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <input v-model="commentData.comment" type="text" class="form-control" size="16">
      </div>
    </div>

    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Category
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <select v-model="selectedCategory">
          <option>Entrance</option>
          <option>Exit</option>
          <option>Social</option>
          <option>Sport</option>
        </select>
      </div>
    </div>
    <button type="submit" class="btn btn-primary" @click.prevent="wrireComment();">Create</button>
    <button type="submit" class="btn btn-primary float-right" @click.prevent="$emit('close')">Cancel</button>
  </div>
</template>

<script>
import * as $ from "jquery";
import DatePicker from "vue2-datepicker";

export default {
  props: ["text"],
  components: { DatePicker },
  data: function() {
    return {
      commentData: {
        comment: "",
        customDate: ""
      },
      selectedCategory: "",
      lang: {
        default: "en"
      }
    };
  },
  methods: {
    getFormDigest: function() {
      return $.ajax({
        //url: "/DEV/BBUlm" + "/_api/contextinfo",
        url: this.$store.state.baseUrlContextinfo,
        method: "POST",
        async: false,
        headers: {
          Accept: "application/json; odata=verbose"
        }
      });
    },
    wrireComment: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      var playerName = this.$store.state.selectedPlayer.Name;
      var date = this.commentData.customDate.toISOString();
      var $this = this;
      var listName = "Comment";
      var itemType = this.GetItemTypeForListName(listName);
      var item = {
        __metadata: {
          type: itemType
        },
        Comment: this.commentData.comment,
        Category: this.selectedCategory,
        Date: date,
        PlayerNameId: playerID
      };
      var baseUrl = this.$store.state.baseUrl;
      var filter = "$filter=id eq '" + this.text + "'";
      baseUrl += "GetByTitle('" + listName + "')/items"; // + filter;
      return this.getFormDigest(baseUrl).then(function(data) {
        $.ajax({
          url: baseUrl,
          type: "POST",
          contentType: "application/json;odata=verbose",
          data: JSON.stringify(item),
          headers: {
            Accept: "application/json;odata=verbose",
            "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
          },
          async: false,
          success: function(data, textStatus, xhr) {
            $this.$emit("close");
            $this.writeHistory(data.d.ID);
          },
          error: function(xhr, textStatus, errorThrown) {
            alert("error:" + JSON.stringify(xhr));
            $("#dialog" + "records").html(" [0]");
          }
        });
      });
    },
    writeHistory: function(CommentRecID) {
      var playerID = this.$store.state.selectedPlayer.ID;
      var playerName = this.$store.state.selectedPlayer.Name;
      var $this = this;
      var listName = "History";
      //var customDate = this.commentData.customDate.toISOString();
      var CurrentDate = this.commentData.customDate.toISOString();
      var itemType = this.GetItemTypeForListName(listName);
      var item = {
        __metadata: {
          type: itemType
        },
        PlayerNameId: playerID,
        date: CurrentDate,
        act: this.selectedCategory,
        details: this.commentData.comment,
        CorrespondingListID: CommentRecID.toString()
      };
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      baseUrl += "GetByTitle('" + listName + "')/items";
      return this.getFormDigest(baseUrl).then(function(data) {
        $.ajax({
          url: baseUrl,
          type: "POST",
          contentType: "application/json;odata=verbose",
          data: JSON.stringify(item),
          headers: {
            Accept: "application/json;odata=verbose",
            "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
          },
          async: false,
          success: function(data, textStatus, xhr) {
            $this.$emit("close");
          },
          error: function(xhr, textStatus, errorThrown) {
            alert("error:" + JSON.stringify(xhr));
            $("#dialog" + "records").html(" [0]");
          }
        });
      });
    },
    GetItemTypeForListName: function(name) {
      return (
        "SP.Data." +
        name.charAt(0).toUpperCase() +
        name
          .split(" ")
          .join("")
          .slice(1) +
        "ListItem"
      );
    }
  }
};
</script>

<style scoped>
.v--modal {
  padding: 10px;
}
.row {
  margin-bottom: 20px;
}
select {
  -webkit-appearance: menulist;
  border-style: solid;
}
</style>
