<template>
  <tr>
    <td style="padding: 10px 0 10px 0px;">{{this.statistic.Datum}}</td>
    <td style="padding: 10px 0 10px 0px;">{{this.statistic.Spiel}}</td>
    <td style="padding: 10px 0 10px 0px;">{{this.statistic.Team}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.FGMA}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.PMA2}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.PMA3}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.FTMA}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.OFF}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.DEF}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;"><b>{{this.statistic.TOT}}</b></td>
    <td style="padding: 10px 0 10px 0px;text-align: center;"><b>{{this.statistic.AST}}</b></td>
    <td style="padding: 10px 0 10px 0px;text-align: center;"><b>{{this.statistic.ST}}</b></td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.TO}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.BS}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.PF}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.FPF}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;">{{this.statistic.EFF}}</td>
    <td style="padding: 10px 0 10px 0px;text-align: center;"><b>{{this.statistic.PTS}}</b></td>
  </tr>
</template>

<script>
import * as $ from "jquery";

export default {
  props: {
    statistic: {
      type: Object
    },
  },
};
</script>

<style>
.myBox:hover {
  background-color: #80808029;
}
</style>
