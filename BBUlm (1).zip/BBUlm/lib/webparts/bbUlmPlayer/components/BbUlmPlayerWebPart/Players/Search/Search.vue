<template>
  <div class="row">
    <vue-autosuggest
      ref="autosuggest"
      @click="clickHandler"
      @keydown.tab.prevent="tabHandler"
      @selected="selectHandler"
      :suggestions="filteredSuggestions"
      :inputProps="inputProps"
      :getSuggestionValue="getSuggestionValue"
    >
      <template slot-scope="{ suggestion }">
        <div>
          <b>{{suggestion.item.name}}</b>
        </div>
      </template>
    </vue-autosuggest>
    <!--  <div v-if="selected">
      You have selected:
      <code>
        <pre>{{JSON.stringify(selected, null, 4)}}</pre>
      </code>
    </div>-->
  </div>
</template>

<script>
export default {
  props: {
    players: {
      type: Array
    }
  },
  mounted: function() {
    //Get the name of players
    this.initPlayersnames();
  },
  data: function() {
    return {
      suggestions: [],
      filteredSuggestions: [],
      selected: null,
      inputProps: {
        id: "autosuggest__input",
        onInputChange: this.fetchResults,
        placeholder: "Geben Sie den Spielername ein",
        class: "ddd"
      }
    };
  },
  methods: {
    initPlayersnames: function() {
      var players = this.$store.state.players;
      for (var i = 0; i < players.length; i++) {
        var playerID = players[i].NameId;
        var fullName = players[i].Name.Name;
        this.suggestions.push({
          PID: playerID,
          name: fullName
        });
      }

      // this.options[0].data = this.playersNames;
    },
    fetchResults: function(text) {
      this.filteredSuggestions = [
        {
          data: this.suggestions.filter(function(item) {
            return item.name.toLowerCase().indexOf(text.toLowerCase()) > -1;
          })
        }
      ];
    },
    selectHandler: function(item) {
      this.selected = item.item.PID;

      this.$store.state.selectedPlayer = this.selected;

      this.$emit("showTabs", true);
      //this.$emit("playerWasSelected", this.selected);
    },
    tabHandler: function() {
      this.$refs.autosuggest.setCurrentIndex(0);
    },
    clickHandler: function(item) {
      this.loading = false;
      this.fetchResults(item ? item.item.name : "");
    },
    getSuggestionValue: function(suggestion) {
      const donut = suggestion.item;
      return donut.name;
    }
  }
};
</script>

<style>
#autosuggest__input {
  outline: none;
  position: relative;
  display: block;
  font-family: monospace;
  font-size: 20px;
  border: 1px solid #616161;
  padding: 10px;
  width: 300px;
  box-sizing: border-box;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  margin-bottom: 20px;
}

#autosuggest__input.autosuggest__input-open {
  border-bottom-left-radius: 0;
  border-bottom-right-radius: 0;
}

.autosuggest__results-container {
  position: relative;
  width: 100%;
}

.autosuggest__results {
  font-weight: 300;
  margin: 0;
  position: absolute;
  z-index: 10000001;
  width: 100%;
  border: 1px solid #e0e0e0;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
  background: white;
  padding: 0px;
  overflow: scroll;
  max-height: 200px;
}

.autosuggest__results ul {
  list-style: none;
  padding-left: 0;
  margin: 0;
}

.autosuggest__results .autosuggest__results_item {
  cursor: pointer;
  padding: 15px;
}

#autosuggest ul:nth-child(1) > .autosuggest__results_title {
  border-top: none;
}

.autosuggest__results .autosuggest__results_title {
  color: gray;
  font-size: 11px;
  margin-left: 0;
  padding: 15px 13px 5px;
  border-top: 1px solid lightgray;
}

.autosuggest__results .autosuggest__results_item:active,
.autosuggest__results .autosuggest__results_item:hover,
.autosuggest__results .autosuggest__results_item:focus,
.autosuggest__results
  .autosuggest__results_item.autosuggest__results_item-highlighted {
  background-color: #ddd;
}
</style>




    