<template> 
  <div> 
    <button type="submit" class="btn btn-primary btn-style" @click.prevent="AddCommentDialog();">Comment</button>
    <button type="submit" class="btn btn-primary btn-style" @click.prevent="AddCharacterDialog()">Character</button>
    <button type="submit" class="btn btn-primary btn-style" @click.prevent="AddStatisticsDialog()">Statistics</button>
    <!--     <button
      type="submit"
      class="btn btn-primary btn-style"
      @click.prevent="wrireCharacter();"
    >Timetable</button>
    <button
      type="submit"
      class="btn btn-primary btn-style"
      @click.prevent="wrireCharacter();"
    >Statistics</button>-->
    <vue-good-table
      ref="sr-table"   
      :ltr="true"
      :columns="columns"
      :rows="rows"
      :pagination-options="{ enabled: true, perPage: 10}"
      :search-options="{ enabled: false}"
      max-height="700px"
      :fixed-header="true"
      @on-row-click="onRowClick"
    >    
      <template slot="table-row" slot-scope="props">
        <span v-if="props.column.field == 'details' && props.row.details != null">

          <span v-if="props.row.details.indexOf(',') == -1">{{props.row.details}}</span> 
          <span v-else-if="props.row.details.split(',')[0] == 'character'">
              <span v-if="props.row.details.split(',')[1] === '1'"  title="Discipline" class="bg-success text-center text-white" style="padding:12px; vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[1] === '2'" title="Discipline" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[1] === '3'" title="Discipline" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[1] === '4'" title="Discipline" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span>
  
              <span v-if="props.row.details.split(',')[2] === '1'" title="Commitment" class="bg-success text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[2] === '2'" title="Commitment" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[2] === '3'" title="Commitment" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[2] === '4'" title="Commitment" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span>

              <span v-if="props.row.details.split(',')[3] === '1'" title="Concentration" class="bg-success text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[3] === '2'" title="Concentration" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[3] === '3'" title="Concentration" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[3] === '4'" title="Concentration" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span>
          </span>   
       <span v-else-if="props.row.details.split(',')[0] == 'statistics'">
            <div title="FGMA" class="d-inline-block ml-1">
              <div style="width: 40px" class="mr-1">
                <span>  
                  <b>FGMA</b> 
                </span>
                <span>{{props.row.details.split(',')[1]}}</span>
              </div>
            </div>
            <div v-if="props.row.details.split(',')[2] !=null" title="PMA2" class="d-inline-block ml-1">
              <div style="width: 40px" class="mr-1">
                <span>
                  <b>PMA2</b>
                </span>
                <span>{{props.row.details.split(',')[2]}}</span>
              </div>    
            </div>
            <div title="FGMA" class="d-inline-block ml-1">
              <div style="width: 40px" class="mr-1">
                <span>
                  <b>PMA3</b>
                </span>
                <span>{{props.row.details.split(',')[3]}}</span>
              </div>
            </div>
            <div title="FTMA" class="d-inline-block ml-1">
              <div style="width: 40px" class="mr-1">
                <span>
                  <b>FTMA</b>
                </span>
                <span>{{props.row.details.split(',')[4]}}</span>
              </div>
            </div>
            <div title="OFF" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>OFF</b>
                </span>
                <span>{{props.row.details.split(',')[5]}}</span>
              </div>
            </div>
            <div title="DEF" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>DEF</b>
                </span>
                <span>{{props.row.details.split(',')[6]}}</span>
              </div>
            </div>
            <div title="TOT" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>TOT</b>
                </span>
                <span>{{props.row.details.split(',')[7]}}</span>
              </div>
            </div>   
            <div title="AST" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>AST</b>
                </span>
                <span>{{props.row.details.split(',')[8]}}</span>
              </div>
            </div>
            <div title="TO" class="d-inline-block ml-1">
              <div style="width: 20px">
                <span>
                  <b>TO</b>
                </span>
                <span>{{props.row.details.split(',')[10]}}</span>
              </div>
            </div>

            <div title="BS" class="d-inline-block ml-1">
              <div style="width: 20px">
                <span>
                  <b>BS</b>
                </span>
                <span>{{props.row.details.split(',')[11]}}</span>
              </div>
            </div> 
            <div title="FPF" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>FPF</b> 
                </span>
                <span>{{props.row.details.split(',')[13]}}</span>
              </div>
            </div> 
            <div title="EFF" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>EFF</b>
                </span>
                <span>{{props.row.details.split(',')[14]}}</span>
              </div>
            </div>

            <div title="PTS" class="d-inline-block ml-1">
              <div style="width: 30px">
                <span>
                  <b>PTS</b>
                </span>
                <span>{{props.row.details.split(',')[15]}}</span>
              </div>
            </div>
            <div title="ST" class="d-inline-block ml-1">
              <div style="width: 20px">
                <span>
                  <b>ST</b>
                </span>
                <span>{{props.row.details.split(',')[9]}}</span>
              </div>
            </div>  
            <div title="PF" class="d-inline-block ml-1">
              <div style="width: 20px">
                <span>
                  <b>PF</b>
                </span>
                <span>{{props.row.details.split(',')[12]}}</span>
              </div>
            </div>        
          </span>


             <!--  <span v-if="props.row.details.split(',')[1] === '1'"  title="Discipline" class="bg-success text-center text-white" style="padding:12px; vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[1] === '2'" title="Discipline" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[1] === '3'" title="Discipline" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[1] === '4'" title="Discipline" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span>
 
              <span v-if="props.row.details.split(',')[2] === '1'" title="Commitment" class="bg-success text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[2] === '2'" title="Commitment" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[2] === '3'" title="Commitment" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[2] === '4'" title="Commitment" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span>

              <span v-if="props.row.details.split(',')[3] === '1'" title="Concentration" class="bg-success text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6;">1</span>
              <span v-else-if="props.row.details.split(',')[3] === '2'" title="Concentration" div class="bg-info text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">2</span>
              <span v-else-if="props.row.details.split(',')[3] === '3'" title="Concentration" div class="bg-warning text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">3</span>
              <span v-else-if="props.row.details.split(',')[3] === '4'" title="Concentration" div class="bg-danger text-center text-white" style="padding:12px;  vertical-align: middle; border-right: 1px solid #dee2e6; ">4</span> -->

        </span>
        <span v-else-if="props.column.field == 'action'">
        <!-- src="https://basketballulm1.sharepoint.com/sites/Playercard//Site Library/img/Entrance.png"-->
        
          <span v-if="props.row.action === 'Entrance'"> 
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/Entrance.png"    style="height:30px ;width:30px">Entrance
          </span>
          <span v-if="props.row.action === 'Social'">
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/Social.png"    style="height:30px ;width:30px">Social
          </span>
          <span v-if="props.row.action === 'Sport'">      
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/Sport.png"    style="height:30px ;width:30px">Sport
          </span>
          <span v-if="props.row.action === 'Exit'">                           
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/Exit.png"   style="height:30px ;width:30px">Exit
          </span>
          <span v-if="props.row.action === 'Character'">                             
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/Character.png"       style="height:30px ;width:30px">Character
          </span>
          <span v-if="props.row.action === 'Statistics'"> 
            <img src="https://basketballulm1.sharepoint.com/sites/Playercard/Site Library/img/flash.png"    style="height:30px ;width:30px">Statistics
          </span>
        </span>


        <span v-else>{{props.formattedRow[props.column.field]}}</span>
      </template>
    </vue-good-table> 
  </div>
</template>

<script>
import * as $ from "jquery";
//import Character from "./Character/Character.vue";
import ShowCharacter from "./Character/ShowCharacter.vue";
import AddCharacter from "./Character/AddCharacter.vue";
import AddComment from "./Comment/AddComment.vue";
import ShowComment from "./Comment/ShowComment.vue";
import AddStatistics from "./Statistics/AddStatistics.vue";
import ShowStatistics from "./Statistics/ShowStatistics.vue";

 

export default {
   components: {
  //  appCharacter: Character,
    appAddCharacter: AddCharacter,
    appAddComment: AddComment,
    appShowCharacter: ShowCharacter,
    appShowComment: ShowComment,
    appAddStatistics: AddStatistics,
    appShowStatistics: ShowStatistics,

  },
  data: function() {
    return {
      baseImageUrl: this.$store.state.baseImageUrl,
      histories: [],

      columns: [
        {
          label: "Created On",
          field: "createdAt",
          type: "date",
          dateInputFormat: "YYYY-MM-DD",
          dateOutputFormat: "DD.MM.YYYY",
          thClass: "text-left",
          tdClass: "text-center",
          width: '151px',
          filterOptions: {
            enabled: true,
            placeholder: "Date",
           // filterFn: this.myColumnFilter
          }
        },
        {
          label: "Action",
          field: "action",
          type: "string",
          width: '135px',
          filterOptions: {
            enabled: true,
            placeholder: "All",
            filterDropdownItems: [
              "Entrance",
              "Social",
              "Sport",
              "Exit",
              "Character",
              "Statistics"
            ]
          }
        },
        {
          label: "Details",
          field: "details",
          type: "string",
          tdClass: "text-left",
          width: '700px',
          filterOptions: {
            enabled: true,
            placeholder: "Details"
          }
        },
/*         {
          label: "CorrespondingListID",
          field: "correspondingListID",
          hidden: true,
          width: '10px',
          type: "string",
          filterOptions: {
            enabled: true,
            placeholder: "Details"
          }
        } */
      ],
      rows: []

       /* rows: [
        {
          createdAt: "201-10-31:9: 35 am",
          action: "Comment",
          details: "John"
        },
        {
          createdAt: "201-10-31:9: 35 am",
          action: "Character",
          details: "John"
        }
      ] */
    };
  },
  created: function() {
    var playerID = this.$store.state.selectedPlayer.ID;
    this.loadHistory(playerID);
  },
  methods: {
    loadHistory: function(playerID) {
      this.rows = [];
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "History";
      var select =
        "$select=id,act,details,date,CorrespondingListID,PlayerName/Name";
      var expand = "&$expand=PlayerName";
      var filter = "&$filter=PlayerNameId eq '" + playerID + "'";
      var orderby = "&$orderby=date desc ";
      baseUrl +=
        "GetByTitle('" +
        listName +
        "')/items?" +
        select +
        expand +
        filter +
        orderby; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.HistorysData(data);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    HistorysData: function(data) {
      var data = data.d.results;
      this.histories = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        var Created = this.getJSONDateAsString(data[i].Created, "dd.MM.yyyy");
 
        $this.rows.push({
          createdAt: data[i].date,
          action: data[i].act,
          details: data[i].details,
          correspondingListID: data[i].CorrespondingListID
        });
      }  
    },
    AddCharacterDialog: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        AddCharacter,
        {
          text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 400,
          height: 400
        },
        {
          closed: function(event) {
            $this.loadHistory(SelectedPlayerID);
          }
        }
      );
    },
    AddCommentDialog: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        AddComment,
        {
          text: SelectedPlayerID
        },
        { 
          draggable: true,
          width: 400,
          height: 400
        },
        {
          closed: function(event) {
            $this.loadHistory(SelectedPlayerID);
          }
        }
      );
    },
    AddStatisticsDialog: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        AddStatistics,
        { 
          text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 550,
          height: 500
        },
        {
          closed: function(event) {
            $this.loadHistory(SelectedPlayerID);
          }
        }
      );
    },
    onRowClick(params) {
      var recordNumbber = params.row.correspondingListID;
      if (params.row.action == "Character") {
        this.showCharacterDialog(recordNumbber);
      } 
      if (
        params.row.action == "Entrance" ||
        params.row.action == "Exit" ||
        params.row.action == "Social" ||
        params.row.action == "Sport"
      ) {
        this.showCommentDialog(recordNumbber);
      }
      if(params.row.action == "Statistics"){
        this.showStatisticsDialog(recordNumbber);
      }

      // showCharacterDialog
      // params.row - row object
      // params.pageIndex - index of this row on the current page.
      // params.selected - if selection is enabled this argument
      // indicates selected or not
      // params.event - click event
    },
    showCharacterDialog: function(recordNumbber) {
      this.$modal.show(
        ShowCharacter,
        {
          characterRecID: recordNumbber
        },
        {
          draggable: true,
          width: 400,
          height: 450
        },
        {
          closed: function(event) {}
        }
      );
    },
    showCommentDialog: function(recordNumbber) {
      this.$modal.show(
        ShowComment,
        {
          CommentRecID: recordNumbber
        }, 
        {
          draggable: true,
          width: 400,
          height: 250
        },
        {
          closed: function(event) {}
        }
      );
    },
    showStatisticsDialog: function(recordNumbber) {
      this.$modal.show(
        ShowStatistics,
        {
          statisticsRecID: recordNumbber
        },
        {
          draggable: true,
          width: 450,
          height: 520
        },
        {
          closed: function(event) {}
        }
      );
    },

    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>

<style scoped>
.btn-style {
  margin: 10px;
} 
.vgt-right-align {
  text-align: center !important;
}
</style>
