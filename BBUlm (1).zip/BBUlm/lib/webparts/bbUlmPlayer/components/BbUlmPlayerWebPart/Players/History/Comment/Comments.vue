<template>
  <!-- Comments Dialogbox  -->
  <div>
    <button type="button" class="btn btn-primary" @click="showCharacterDialogEditMode">Add Character</button>
  </div>
</template>

<script>
import * as $ from "jquery";
//import Character from "./Character.vue";
import AddComment from "./AddComment.vue";
export default {
  data: function() {
    return {
      characters: []
    };
  },
  created: function() {
    var playerID = this.$store.state.selectedPlayer.ID;
   // this.loadCharacters(playerID);
  },
  components: {
    //appCharacter: Character,
    appAddComment: AddComment
  },
  methods:{
    addCommentDialog: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        appAddComment,
        {
          text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 400,
          height: 400
        },
        {
          closed: function(event) {
            $this.$parent.loadHistory(SelectedPlayerID);
           // loadCharacters(SelectedPlayerID);
          }
        }
      );
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
  }
};
</script>

<style>
</style>
