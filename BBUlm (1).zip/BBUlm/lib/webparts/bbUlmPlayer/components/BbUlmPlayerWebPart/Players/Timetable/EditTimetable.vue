<template>
  <div class="container p-3">
    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Start
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <date-picker
          v-model="eventData.EventDate"
          :lang="lang"
          type="datetime"
          format="DD.MM.YYYY HH:mm"
          :minute-step="15"
          :placeholder="eventData.EventDate"
          confirm
        ></date-picker>
        <span v-show=" this.errors.start" class="text-danger">The start field is required.</span>
      </div>
    </div>
    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        End
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <date-picker
          v-model="eventData.EndDate"
          :lang="lang"
          type="datetime"
          format="DD.MM.YYYY HH:mm"
          :minute-step="15"
          :placeholder="eventData.EndDate"
          confirm
        ></date-picker>
        <span v-show=" this.errors.end" class="text-danger">The end field is required.</span>
      </div>
    </div>

    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Title
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <input v-model="eventData.Title" type="text" class="form-control" size="16">
        <span v-show=" this.errors.titel" class="text-danger">The title field is required.</span>
      </div>
    </div>

    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        Location
        <font color="red">*</font>
      </div>
      <div class="d-inline col-lg-8 col-md-8 col-sm-8" padding="0px">
        <select v-model="SelectedLocalization">
          <option
            v-for="localization in localizations"
            v-bind:value="localization.Titel"
          >{{ localization.Titel }}</option>
        </select>
        <span v-show=" this.errors.titel" class="text-danger">The category field is required.</span>
      </div>
    </div>

    <div class="row">
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">Weekly recurring</div>
      <div class="d-inline col-lg-4 col-md-4 col-sm-4" padding="0px">
        <input type="checkbox" id="checkbox" v-model="eventData.Recurrence">
      </div>
    </div>

    <button type="submit" class="btn btn-primary" @click.prevent="validateForm();">Save</button>
    <button type="submit" class="btn btn-primary float-right" @click.prevent="$emit('close')">Cancel</button>
  </div>
</template>

<script>
import * as $ from "jquery";
import DatePicker from "vue2-datepicker";

export default {
  mounted: function() {
    this.init();
  },
  props: ["text"],
  components: { DatePicker },
  data: function() {
    return {
      eventData: "",
      lang: {
        default: "en"
      },
      valid: true,
      errors: {
        start: "",
        end: "",
        titel: ""
      },
      localizations: [],
      SelectedLocalization: ""
    };
  },

  methods: {
    init: function() {
      this.eventData = Object.assign({}, this.$store.state.selectedEvent); //Copy without  reference
      this.loadLocalization();
    },
    getFormDigest: function() {
      return $.ajax({
        //url: "/DEV/BBUlm" + "/_api/contextinfo",
        url: this.$store.state.baseUrlContextinfo,  
        method: "POST",
        headers: {
          Accept: "application/json; odata=verbose"
        }
      });
    },

    validateForm: function() {
      this.valid = true;
      this.errors = {};

      if (!this.eventData.EventDate) {
        this.errors.start = true;
        this.valid = false;
      }
      if (!this.eventData.EndDate) {
        this.errors.end = true;
        this.valid = false;
      }
      if (!this.eventData.Title) {
        this.errors.titel = true;
        this.valid = false;
      }

      if (this.valid) {
        this.errors.start = false;
        this.errors.end = false;
        this.errors.titel = false;
        this.wrireEvent();
      }
    },

    wrireEvent: function() {
      var reccurenceString;
      var eventType;
      var item;
      var playerID = this.$store.state.selectedPlayer.ID;
      var eventID = this.$store.state.selectedEvent.id;
      var $this = this;
      var listName = "Calendar";
      var itemType = this.GetItemTypeForListName(listName);
      //  var stringStartDate = this.eventData.EventDate.toISOString();
      var stringEndDate = new Date(this.eventData.EndDate).toISOString();
      var eventDateUTCFormat = new Date(this.eventData.EventDate).toUTCString();
     /*  
      if (this.isIsoDate(stringEndDate)) {
        var stringEndDate = this.eventData.EndDate;
      } else {
        var stringEndDate = this.eventData.EndDate.toISOString();
      } */
      var firstTwoCharacterDate = eventDateUTCFormat
        .toString()
        .substr(0, 2)
        .toLowerCase();

      if (this.eventData.Recurrence) {
        reccurenceString =
          " <recurrence><rule><firstDayOfWeek>mo</firstDayOfWeek><repeat><weekly " +
          firstTwoCharacterDate +
          "='TRUE' weekFrequency='1' /></repeat><windowEnd>" +
          stringEndDate +
          "</windowEnd></rule></recurrence>";
        eventType = 1;
        item = {
          __metadata: {
            type: itemType
          },
          EventDate: new Date(this.eventData.EventDate),
          EndDate: new Date(stringEndDate),
          Title: this.eventData.Title,
          Location: this.SelectedLocalization,
          fRecurrence: this.eventData.Recurrence,
          RecurrenceData: reccurenceString,
          EventType: eventType,
          PlayerID: playerID
        };
      } else {
        reccurenceString = "";
        eventType = 0;
        item = {
          __metadata: {
            type: itemType
          },
          EventDate: new Date(this.eventData.EventDate),
          EndDate: new Date(this.eventData.EndDate),
          Title: this.eventData.Title,
          Location: this.SelectedLocalization,
          fRecurrence: this.eventData.Recurrence,
          RecurrenceData: reccurenceString,
          PlayerID: playerID,
          EventType: eventType
        };
      }

      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      baseUrl += "GetByTitle('" + listName + "')/items(" + eventID + ")";
      return this.getFormDigest(baseUrl).then(function(data) {
        $.ajax({
          url: baseUrl,
          type: "POST",
          contentType: "application/json;odata=verbose",
          data: JSON.stringify(item),
          headers: {
            Accept: "application/json;odata=verbose",
            "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue,
            "X-HTTP-Method": "MERGE",
            "If-Match": "*"
          },
          async: false,

          success: function(data, textStatus, xhr) {
            $this.$emit("close");
          },
          error: function(xhr, textStatus, errorThrown) {
            alert("error:" + JSON.stringify(xhr));
            $("#dialog" + "records").html(" [0]");
          }
        });
      });
    },
    GetItemTypeForListName: function(name) {
      return (
        "SP.Data." +
        name.charAt(0).toUpperCase() +
        name
          .split(" ")
          .join("")
          .slice(1) +
        "ListItem"
      );
    },
    loadLocalization: function() {
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Location";
      var select = "$select=id,Title";
      baseUrl += "GetByTitle('" + listName + "')/items?" + select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.localizationsData(data);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    localizationsData: function(data) {
      var data = data.d.results;
      this.localizations = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        $this.localizations.push({
          id: data[i].ID,
          Titel: data[i].Title
        });
      }
      this.SelectedLocalization = this.eventData.Location;
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    },
    isIsoDate: function(str) {
      if (!/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/.test(str)) return false;
      var d = new Date(str);
      return d.toISOString() === str;
    }
  }
};
</script>

<style scoped>
.v--modal {
  padding-top: 15px;
  padding-left: 10px;
}
.row {
  margin-bottom: 20px;
}
select {
  -webkit-appearance: menulist;
  border-style: solid;
}
</style>
