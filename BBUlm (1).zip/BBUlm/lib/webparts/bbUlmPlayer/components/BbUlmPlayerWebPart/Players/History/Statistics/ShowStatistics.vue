<template >
  <div class="container p-2">
    
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">FGMA</h5>
        <p class="card-text" v-if="this.FGMA !=null">{{this.FGMA}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">PMA2</h5>
        <p class="card-text" v-if="this.PMA2 !=null">{{this.PMA2}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">PMA3</h5>
        <p class="card-text" v-if="this.PMA3 !=null">{{this.PMA3}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">FTMA</h5>
        <p class="card-text" v-if="this.FTMA !=null">{{this.FTMA}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">OFF</h5>
        <p class="card-text" v-if="this.OFF !=null">{{this.OFF}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">DEF</h5>
        <p class="card-text" v-if="this.DEF !=null">{{this.DEF}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">TOT</h5>
        <p class="card-text" v-if="this.TOT !=null">{{this.TOT}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">AST</h5>
        <p class="card-text" v-if="this.AST !=null">{{this.AST}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">ST</h5>
        <p class="card-text" v-if="this.ST !=null">{{this.ST}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">TO</h5>
        <p class="card-text" v-if="this.TO !=null">{{this.TO}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">BS</h5>
        <p class="card-text" v-if="this.BS !=null">{{this.BS}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">PF</h5>
        <p class="card-text" v-if="this.PF !=null">{{this.PF}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">FPF</h5>
        <p class="card-text" v-if="this.FPF !=null">{{this.FPF}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">EFF</h5>
        <p class="card-text" v-if="this.EFF !=null">{{this.EFF}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 100px;">
      <div class="card-body">
        <h5 class="card-title">PTS</h5>
        <p class="card-text" v-if="this.PTS !=null">{{this.PTS}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 200px;">
      <div class="card-body">
        <h5 class="card-title">Play Location</h5>
        <p class="card-text" v-if="this.Playloc !=null">{{this.Playloc}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    <div class="card d-inline-block" style="width: 150px;">
      <div class="card-body">
        <h5 class="card-title">Date</h5>
        <p class="card-text" v-if="this.Date !=null">{{this.Date}}</p>
        <p class="card-text" v-else>N/A</p>
      </div>
    </div>
    


  </div>
</template>

<script>
import * as $ from "jquery";

export default {
  props: ["statisticsRecID"],
  data: function() {
    return {
      FGMA: "",
      PMA2: "",
      PMA3: "",
      FTMA: "",
      OFF: "",
      DEF: "",
      TOT: "",
      AST: "",
      ST: "",
      TO: "",
      BS: "",
      PF: "",
      FPF: "",
      EFF: "",
      PTS: "",
      Playloc: "",
      Date: ""
    };
  },

  mounted: function() {
    this.loadStatistics();
  },
  methods: {
    loadStatistics: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Statistics";
      //var select = "$select=id, Firstname,lastname";
      var filter = "$filter=ID eq '" + this.statisticsRecID + "'";
      baseUrl += "GetByTitle('" + listName + "')/items?" + filter; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.statisticsData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    statisticsData: function(data) {
        this.Date = this.getJSONDateAsString(data[0].Datum, "dd.MM.yyyy");
        this.FGMA = data[0].FGM_x002d_A
        this.PMA2 = data[0].OData__x0032_PM_x002d_A
        this.PMA3 = data[0].OData__x0033_PM_x002d_A
        this.FTMA = data[0].FTM_x002d_A
        this.OFF = data[0].OFF
        this.DEF = data[0].DEF
        this.TOT = data[0].TOT
        this.TOT = data[0].ASTOTT
        this.AST = data[0].AST
        this.ST = data[0].ST
        this.TO = data[0].TO
        this.BS = data[0].BS
        this.PF = data[0].PF
        this.FPF = data[0].FPF
        this.EFF = data[0].EFF
        this.PTS = data[0].PTS
        this.Playloc = data[0].Spiel
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>

<style scoped>
.v--modal {
  padding: 15px;

}
/* #tblScores tr,
#tblScores td,
#tblScores th {
  border: 0 !important;
} */
</style>
