<template>
  <tr>
    <td v-if="this.event.Recurrence === true" style="padding:5px">
      <a href="#" @click="eventIsSelected(event.id)">Every {{WRDate}}</a>
    </td>
    <td v-if="this.event.Recurrence === false" style="padding:5px">
      <a href="#" @click="eventIsSelected(event.id)">{{this.event.FormattedDate}}</a>
    </td>

    <td style="padding:5px">{{this.event.StartTime}}</td>
    <td style="padding:5px">{{this.event.EndTime}}</td>
    <td style="padding:5px">{{this.event.Title}}</td>
    <td style="padding:5px">{{this.event.Location}}</td>
    <td style="padding:5px" class="text-center">
      <div v-if="this.event.Recurrence=== true">
        <input type="checkbox" disabled checked>
      </div>
      <div v-else>
        <input type="checkbox" disabled>
      </div>
    </td>
  </tr>
</template>

<script>
import EditTimetable from "./EditTimetable.vue";
export default {
  props: {
    event: {
      type: Object
    }
  },

  components: {
    appEditTimetable: EditTimetable
  },

  computed: {
    WRDate: function() {
      if (this.event.Recurrence) {
        var dateFirstDay = this.getJSONDateAsString(
          this.event.EventDate,
          "MM.dd.yyyy"
        );
        var date = this.getJSONDateAsString(dateFirstDay, "dddd");
        return date;

        /*         switch (Datum) {
          case "Monday":
            return "Montag";
            break;
          case "Tuesday":
            return "Dienstag";
            break;
          case "Wednesday":
            return "Mittwoch";
            break;

          case "Thursday":
            return "Donnerstag";
            break;
          case "Friday":
            return "Freitag";
            break;
          case "Saturday":
            return "Samstag";
            break;
          case "Sunday":
            return "Sonntag";
            break;
          default:
            return "Not Match";
        } */
      }
    }
  },
  data: function() {
    return {
      counter: 0
    };
  },
  methods: {
    eventIsSelected: function(eventID) {
      this.$store.state.selectedEvent = this.event;
      this.editEvent();
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    },
    editEvent: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        EditTimetable,
        {
          // text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 400,
          height: 450
        },
        {
          closed: function(event) {
            $this.$parent.loadEvents(SelectedPlayerID);
          }
        }
      );
    }
  }
};
</script>

<style>
</style>
