<template>
  <div class="container">
    <table class="table table-hover" id="tblScores">
      <tbody>
        <tr>
          <th scope="row">Disziplin</th>

          <td v-if="Discipline === '1'" class="bg-success text-center">{{Discipline}}</td>
          <td v-else-if="Discipline === '2'" div class="bg-info text-center">{{Discipline}}</td>
          <td v-else-if="Discipline === '3'" class="bg-warning text-center">{{Discipline}}</td>
          <td v-else-if="Discipline === '4'" class="bg-danger text-center">{{Discipline}}</td>
        </tr>
        <tr>
          <th scope="row">Einsatz</th>
          <td v-if="Commitment == '1'" class="bg-success text-center">{{Commitment}}</td>
          <td v-else-if="Commitment == '2'" div class="bg-info text-center">{{Commitment}}</td>
          <td v-else-if="Commitment== '3'" class="bg-warning text-center">{{Commitment}}</td>
          <td v-else-if="Commitment == '4'" class="bg-danger text-center">{{Commitment}}</td>
        </tr>
        <tr>
          <th scope="row">Konzentration</th>
          <td v-if="Concentration == '1'" class="bg-success text-center">{{Concentration}}</td>
          <td v-else-if="Concentration == '2'" div class="bg-info text-center">{{Concentration}}</td>
          <td v-else-if="Concentration == '3'" class="bg-warning text-center">{{Concentration}}</td>
          <td v-else-if="Concentration == '4'" class="bg-danger text-center">{{Concentration}}</td>
        </tr>
      </tbody>
    </table>
    <table class="table table-hover" id="tblScores">
      <tbody>
        <tr>
          <th scope="row">Ziel für das Jahr</th>
          <td style="text-align: right">{{Goal}}</td>
        </tr>
        <tr>
          <th scope="row">Trainings Motivation</th>
          <td style="text-align: right">{{Motivation}}</td>
        </tr>
        <tr>
          <th scope="row">Bewerter</th>
          <td style="text-align: right">{{this.Evaluator}}</td>
        </tr>
      </tbody>
    </table>
    <table class="table table-hover">
      <tbody>
        <tr>
          <th scope="row">Gesamtwert</th>
          <td v-if="totalScore == '1'" class="bg-success text-center">{{totalScore}}</td>
          <td v-else-if="totalScore == '2'" div class="bg-info text-center">{{totalScore}}</td>
          <td v-else-if="totalScore == '3'" class="bg-warning text-center">{{totalScore}}</td>
          <td v-else-if="totalScore == '4'" class="bg-danger text-center">{{totalScore}}</td>
        </tr>
      </tbody>
    </table>

    <button type="submit" class="btn btn-primary float-right" @click.prevent="$emit('close')">Cancel</button>
  </div>
</template>

<script>
import * as $ from "jquery";

export default {
  props: ["characterRecID"],
  data: function() {
    return {
      Discipline: "",
      Commitment: "",
      Concentration: "",
      Goal: "",
      Motivation: "",
      Evaluator: "",
      totalScore: 0,
      coath: "",
      assistantCoach: ""
    };
  },

  mounted: function() {
    this.loadCharacters();
  },
  methods: {
    loadCharacters: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Character";
      //var select = "$select=id, Firstname,lastname";
      var filter = "$filter=ID eq '" + this.characterRecID + "'";
      baseUrl += "GetByTitle('" + listName + "')/items?" + filter; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.charactersData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    charactersData: function(data) {
      this.Discipline = data[0].Discipline;
      this.Commitment = data[0].Commitment;
      this.Concentration = data[0].Concentration;
      this.Goal = data[0].Goal;
      this.Motivation = data[0].Motivation;
      this.Evaluator = data[0].Evaluator;
      var Dis = parseInt(this.Discipline);
      var Com = parseInt(this.Commitment);
      var con = parseInt(this.Concentration);
      this.totalScore = Math.round((Dis + Com + con) / 3);
    },

  }
};
</script>

<style scoped>
.v--modal {
  padding-top: 15px;
  padding-left: 10px;
}
/* #tblScores tr,
#tblScores td,
#tblScores th {
  border: 0 !important;
} */
</style>
