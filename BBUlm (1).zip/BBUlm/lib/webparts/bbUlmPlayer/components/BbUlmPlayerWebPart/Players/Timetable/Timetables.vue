<template>
  <div>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">Date</th>
          <th scope="col">Start</th>
          <th scope="col">End</th>
          <th scope="col">Title</th>
          <th scope="col">Location</th>
          <th scope="col" class="text-center">Weekly recurring</th>
        </tr>
      </thead>
      <tbody>
        <app-timetable v-for="(event, index) in events" :event="event" :index="index++"></app-timetable>
      </tbody>
    </table>

    <div>
      <button type="button" class="btn btn-primary" @click="addEvent">Add timetable</button>
    </div>
  </div>
</template>
 
template
<script>
import * as $ from "jquery";
import Timetable from "./Timetable.vue";
import AddTimetable from "./AddTimetable.vue";

export default {
  components: {
    appTimetable: Timetable,
    appAddTimetable: AddTimetable
  },
  data: function() {
    return {
      events: []
    };
  },
  created: function() {
    this.loadEvents();
    //this.testCalender();
  },
  methods: {
    loadEvents: function(data) {
      var playerID = this.$store.state.selectedPlayer.ID;
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Calendar";
      var filter = "$filter=PlayerID eq '" + playerID + "'";
      var orderby = "&$orderby=EventDate desc ";
      baseUrl += "GetByTitle('" + listName + "')/items?" + filter + orderby;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          //alert("success");
          $this.eventsData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },

    eventsData: function(data) {
      this.events = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        var StartTime = this.getJSONDateAsString(data[i].EventDate, "HH:mm");
        var EndTime = this.getJSONDateAsString(data[i].EndDate, "HH:mm");
        var formatedDate = this.getJSONDateAsString(data[i].EventDate, "dd.MM.yyyy");
        $this.events.push({
          id: data[i].ID,
          FormattedDate: formatedDate,
          Location: data[i].Location,
          Title: data[i].Title,
          Recurrence: data[i].fRecurrence, 
          EventDate: data[i].EventDate,
          StartTime: StartTime,
          StartDate: data[i].EventDate,
          EndTime: EndTime,
          EndDate: data[i].EndDate
        });
      }
    },
    addEvent: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        AddTimetable,
        {
          text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 400,
          height: 450
        },
        {
          closed: function(event) {
            $this.loadEvents(SelectedPlayerID);
          }
        }
      );
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>