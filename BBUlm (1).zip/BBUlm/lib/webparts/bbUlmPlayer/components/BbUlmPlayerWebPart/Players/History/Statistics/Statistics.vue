<template>
  <div>
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col" class="text-left" style="padding: 10px 0 10px 0px;">Date</th>
          <th scope="col" class="text-left" style="padding: 10px 0 10px 0px;">Play</th>
          <th scope="col" class="text-left" style="padding: 10px 0 10px 0px;">Team</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">FGM-A</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">2PM-A</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">3PM-A</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">FTM-A</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">OFF</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">DEF</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">TOT</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">AST</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">ST</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">TO</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">BS</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">PF</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">FPF</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">EFF</th>
          <th scope="col" class="text-center" style="padding: 10px 0 10px 0px;">PTS</th>
        </tr>
      </thead>
      <tbody>
        <app-statistic v-for="(statistic, index) in statistics" :statistic="statistic"></app-statistic>
      </tbody>
    </table>
  </div>
</template>


<script>
import * as $ from "jquery";
import Statistic from "./Statistic.vue";
export default {
  components: {
    appStatistic: Statistic
  },
  data: function() {
    return {
      statistics: []
    };
  },
  created: function() {
    this.loadStatistics();
  },
  methods: {
    loadStatistics: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Statistics";
      var select =
        "$select=id,Spiel,Datum,OData__x0032_PM_x002d_A,OData__x0033_PM_x002d_A ,FGM_x002d_A,FTM_x002d_A,OFF,DEF,TOT,AST,ST,TO,BS,PF,FPF,EFF,PTS,Team/TeamName";
      var expand = "&$expand=Team";
      var filter = "&$filter=PlayerNameId eq '" + playerID + "'";
      var orderby = "&$orderby=Datum desc ";
      baseUrl += "GetByTitle('" + listName + "')/items?" + select+expand+ filter + orderby; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          //alert("success");
          $this.statisticsData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },

    statisticsData: function(data) {
      this.statistics = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        var Datum = this.getJSONDateAsString(data[i].Datum, "dd.MM.yyyy");
        $this.statistics.push({
          id: data[i].ID,
          Spiel: data[i].Spiel,
          Team: data[i].Team.TeamName,
          Datum: Datum,
          PMA2: data[i].OData__x0032_PM_x002d_A,
          PMA3: data[i].OData__x0033_PM_x002d_A,
          FGMA: data[i].FGM_x002d_A,
          FTMA: data[i].FTM_x002d_A,
          OFF: data[i].OFF,
          DEF: data[i].DEF,
          TOT: data[i].TOT,
          AST: data[i].AST,
          ST: data[i].ST,
          TO: data[i].TO,
          BS: data[i].BS,
          PF: data[i].PF,
          FPF: data[i].FPF,
          EFF: data[i].EFF,
          PTS: data[i].PTS
        });
      }
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>

