<template>
  <div>
    <!-- Characters Infos -->
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col" class="text-center" style="width:15px;border: 0">#</th>
          <th scope="col" class="text-left" style="width:35px;border: 0">Date</th>
          <th scope="col" class="text-left" style="width:35px;border: 0">Evaluator</th>
          <th
            scope="col"
            class="text-center"
            style=" width:20px; border: 0"
            data-placement="top"
            title="Discipline"
          >Dis. </th>
          <th
            scope="col"
            class="text-center"
            style="width:20px; border: 0"
            data-placement="top"
            title="Commitment"
          >Com.</th>
          <th
            scope="col"
            class="text-center"
            style="width:20px; border: 0"
            data-placement="top"
            title="Concentration"
          >Con.</th>

          <th
            scope="col"
            class="text-left"
            style="width:50px; border: 0"
            data-placement="top"
            title="Ziel"
          >Goal</th>
          <th
            scope="col"
            class="text-left"
            style="width:50px; border: 0"
            data-placement="top"
            title="Motivation"
          >Motivation</th>
        </tr>
      </thead>
      <tbody>
        <app-character
          v-for="(character, index) in characters"
          :character="character"
          :index="index++"
        ></app-character>
      </tbody>
    </table>

    <!-- Characters Dialogbox  -->
    <div>
      <button
        type="button"
        class="btn btn-primary"
        @click="showCharacterDialogEditMode"
      >Add Character</button>
    </div>
  </div>
</template>

<script>
import * as $ from "jquery";
//import Character from "./Character.vue";
import AddCharacter from "./AddCharacter.vue";
export default {
  data: function() {
    return {
      characters: []
    };
  },
  created: function() {
    var playerID = this.$store.state.selectedPlayer.ID;
    this.loadCharacters(playerID);
  },
  components: {
  //  appCharacter: Character,
    appAddCharacter: AddCharacter
  },
  methods: {
    loadCharacters: function(playerID) {
     //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Character";
      var select =
        "$select=id,Evaluator,Discipline,Commitment,Concentration,Goal,Motivation,Created,PlayerName/Name";
      var expand = "&$expand=PlayerName";
      var filter = "&$filter=PlayerNameId eq '" + playerID + "'";
      var orderby = "&$orderby=Created desc ";
      baseUrl +=
        "GetByTitle('" +
        listName +
        "')/items?" +
        select +
        expand +
        filter +
        orderby; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.charactersData(data);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    charactersData: function(data) {
      var data = data.d.results;
      var trimmedGoal = "",
        trimmedMotivation = "";
      this.characters = [];
      var $this = this;
      for (var i = 0; i < data.length; i++) {
        var Created = this.getJSONDateAsString(data[i].Created, "dd.MM.yyyy");
        if (data[i].Goal.length > 15) {
          trimmedGoal = data[i].Goal.substring(0, 15);
        } else {
          trimmedGoal = "";
        }
        if (data[i].Motivation.length > 15) {
          trimmedMotivation = data[i].Motivation.substring(0, 15);
        } else {
          trimmedMotivation = "";
        }
        $this.characters.push({
          id: data[i].ID,
          Discipline: data[i].Discipline,
          Commitment: data[i].Commitment,
          Concentration: data[i].Concentration,
          Goal: data[i].Goal,
          trimmedGoal: trimmedGoal,
          Motivation: data[i].Motivation,
          trimmedMotivation: trimmedMotivation,
          Evaluator: data[i].Evaluator,
          CreatedDate: Created
        });
      }
    },
    showCharacterDialogEditMode: function() {
      var SelectedPlayerID = this.$store.state.selectedPlayer.ID;
      var $this = this;
      this.$modal.show(
        AddCharacter,
        {
          text: SelectedPlayerID
        },
        {
          draggable: true,
          width: 400,
          height: 400
        },
        {
          closed: function(event) {
            $this.loadCharacters(SelectedPlayerID);
          }
        }
      );
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>

<style>
</style>
