<template>
  <div class="container">
    <table class="table table-hover">
      <tbody>
        <tr>
          <th scope="row" style="width:100px; padding-left:0;padding-right:0">Disziplin</th>

          <td style="padding:0; width:20px">
            <div class="btn btn-success" style="margin:5px" @click="selectedDiscipline='1'">1</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-info" style="margin:5px" @click="selectedDiscipline='2'">2</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-warning" style="margin:5px" @click="selectedDiscipline='3'">3</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-danger" style="margin:5px" @click="selectedDiscipline='4'">4</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div v-if="selectedDiscipline" style="margin-left:5px ; display: inline-block">
              <img
                :src="this.$store.state.baseImageUrl +'/Site Library/img/tik.png'"
                style="height:30px ;width:30px"
              >
            </div>
          </td>
        </tr>
  
        <tr>
          <th scope="row" style="width:100px; padding-left:0;padding-right:0">Einsatz</th>

          <td style="padding:0; width:20px">
            <div class="btn btn-success" style="margin:5px" @click="selectedCommitment='1'">1</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-info" style="margin:5px" @click="selectedCommitment='2'">2</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-warning" style="margin:5px" @click="selectedCommitment='3'">3</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-danger" style="margin:5px" @click="selectedCommitment='4'">4</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div v-if="selectedCommitment" style="margin-left:5px ; display: inline-block">
              <img
                :src="this.$store.state.baseImageUrl +'/Site Library/img/tik.png'"
                style="height:30px ;width:30px"
              >
            </div>
          </td>
        </tr>
   
        <tr>
          <th scope="row" style="width:100px; padding-left:0;padding-right:0">Konzentration</th>

          <td style="padding:0; width:20px">
            <div class="btn btn-success" style="margin:5px" @click="selectedConcentration='1'">1</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-info" style="margin:5px" @click="selectedConcentration='2'">2</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-warning" style="margin:5px" @click="selectedConcentration='3'">3</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div class="btn btn-danger" style="margin:5px" @click="selectedConcentration='4'">4</div>
          </td>
          <td style="padding:0 ; width:20px">
            <div v-if="selectedConcentration" style="margin-left:5px ; display: inline-block">
              <img
                :src="this.$store.state.baseImageUrl +'/Site Library/img/tik.png'" 
                style="height:30px ;width:30px"
              >
            </div>
          </td>
        </tr> 
      </tbody>
    </table>
    <table class="table table-hover">
      <tbody>
        <tr>
          <th scope="row" style="width:100px; padding:0">Ziel für das Jahr</th>
          <td>
            <input v-model="playerData.goal" type="text" class="form-control" size="16">
          </td>
        </tr>
        <tr>
          <th scope="row" style="width:100px; padding:0">Trainings Motivation</th>
          <td>
            <input v-model="playerData.motivation" type="text" class="form-control" size="16">
          </td>
        </tr>  
        <tr>
          <th scope="row" style="width:100px; padding:0">Bewerter</th>
          <td>
            <select v-model="SelectedEvaluaor">
              <option
                v-for="evaluator in evaluators"
                v-bind:value="evaluator.name"
              >{{ evaluator.name }}</option>
            </select> 
          </td>
        </tr>
      </tbody>
    </table>
    <button type="submit" class="btn btn-primary" @click.prevent="wrireCharacter();">Create</button>
    <button type="submit" class="btn btn-primary float-right" @click.prevent="$emit('close')">Cancel</button>
  </div>
</template>

<script>
import * as $ from "jquery";

export default {
  props: ["text"],
  data: function() {
    return {
      playerData: {
        discipline: "",
        commitment: "",
        concentration: "",
        goal: "",
        motivation: ""
      },
      evaluators: [] /* [{ name: "One" }, { name: "Two" }, { text: "Three" }] */,
      //  disciplines: ["1", "2", "3", "4"],
      selectedDiscipline: "",
      //commitments: ["1", "2", "3", "4"],
      selectedCommitment: "",
      //concentrations: ["1", "2", "3", "4"],
      selectedConcentration: "",
      SelectedEvaluaor: "",
    };
  },
  created: function() {
    this.loadBewerter();
  },
  methods: {
    loadBewerter: function() {
      var team = this.$store.state.selectedTeam;
      this.evaluators.push({
        name: team.Coach,
      });
      this.evaluators.push({
        name: team.CoachAssistant
      });
      this.SelectedEvaluaor = team.Coach;
    },
    getFormDigest: function() {
      return $.ajax({
        //url: "/DEV/BBUlm" + "/_api/contextinfo",
        url: this.$store.state.baseUrlContextinfo,  
        method: "POST",
        async: false,
        headers: {
          Accept: "application/json; odata=verbose"
        }
      });
    },
    wrireCharacter: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      var playerName = this.$store.state.selectedPlayer.Name;
      var $this = this;
      var listName = "Character";
      var itemType = this.GetItemTypeForListName(listName);
      var item = {
        __metadata: {
          type: itemType
        },
        Discipline: this.selectedDiscipline,
        Commitment: this.selectedCommitment,
        Concentration: this.selectedConcentration,
        Goal: this.playerData.goal,
        Motivation: this.playerData.motivation,
        Evaluator: this.SelectedEvaluaor,
        PlayerNameId: playerID.toString()
        // Name: playerName
        // this.text.toString()
      };
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var filter = "$filter=id eq '" + this.text + "'";
      baseUrl += "GetByTitle('" + listName + "')/items"; // + filter;
      return this.getFormDigest(baseUrl).then(function(data) {
        $.ajax({
          url: baseUrl,
          type: "POST",
          contentType: "application/json;odata=verbose",
          data: JSON.stringify(item),
          headers: {
            Accept: "application/json;odata=verbose",
            "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
          },
          async: false,
          success: function(data, textStatus, xhr) {
            $this.writeHistory(data.d.ID);
          },
          error: function(xhr, textStatus, errorThrown) {
            alert("fail");
            alert("error:" + JSON.stringify(xhr));
            $("#dialog" + "records").html(" [0]");
          }
        });
      });
    },
    writeHistory: function(CharacterRecID){
      var playerID = this.$store.state.selectedPlayer.ID;
      var playerName = this.$store.state.selectedPlayer.Name;
      var $this = this;
      var listName = "History";
      var characterDetails =  "character," + this.selectedDiscipline + ',' + this.selectedCommitment + ',' + this.selectedConcentration
      var CurrentDate = new Date();
      CurrentDate = CurrentDate.toISOString();
      var itemType = this.GetItemTypeForListName(listName);
      var item = {
        __metadata: {
          type: itemType
        },
        PlayerNameId: playerID,
        date: CurrentDate,
        act: 'Character',
        details: characterDetails,
        CorrespondingListID: CharacterRecID.toString()
      };
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      baseUrl += "GetByTitle('" + listName + "')/items"; 
      return this.getFormDigest(baseUrl).then(function(data) {
        $.ajax({
          url: baseUrl,
          type: "POST",
          contentType: "application/json;odata=verbose",
          data: JSON.stringify(item),
          headers: {
            Accept: "application/json;odata=verbose",
            "X-RequestDigest": data.d.GetContextWebInformation.FormDigestValue
          },
          async: false,
          success: function(data, textStatus, xhr) {
            $this.$emit("close");
          },
          error: function(xhr, textStatus, errorThrown) {
            alert("error:" + JSON.stringify(xhr));
            $("#dialog" + "records").html(" [0]");
          }
        }); 
      });
    },
    GetItemTypeForListName: function(name) {
      return (
        "SP.Data." +
        name.charAt(0).toUpperCase() +
        name
          .split(" ")
          .join("")
          .slice(1) +
        "ListItem"
      );
    }
  }
};
</script>

<style scoped>
.v--modal {
  padding-top: 15px;
  padding-left: 10px;
}
select {
  -webkit-appearance: menulist;
  border-style: solid;
}
</style>
