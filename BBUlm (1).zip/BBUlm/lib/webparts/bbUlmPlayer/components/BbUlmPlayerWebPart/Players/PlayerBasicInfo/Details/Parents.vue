<template>
  <div class="col-lg-6 col-md-6 col-sm-6">
    <div class="row">
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">
        <b>{{this.parent.ParentType}}</b>
      </div>
        <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">
      {{this.parent.ParentName}}
      </div>
    </div>
    <div class="row" style="margin-bottom:5px">
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">
        <b>Phone</b>
      </div>
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">{{this.parent.Telephone}}</div>
    </div>
    <div class="row" style="margin-bottom:5px">
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">
        <b>E-Mail</b>
      </div>
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">{{this.parent.Email}}</div>
    </div>

    <div class="row" style="margin-bottom:10px">
      <div class="d-inline col-lg-6 col-md-6 col-sm-12" padding="0px">
        <b>Details/General Info</b>
      </div>
      <div class="d-inline col-lg-6 col-md-6 col-sm-12" padding="0px">{{this.parent.Gerneralinfo}}</div>
    </div>
    <div class="row" style="margin-bottom:5px">
      <div class="d-inline col-lg-6 col-md-6 col-sm-12" padding="0px">
        <b>Address</b>
      </div>
      <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">{{this.parent.Address}}</div>
    </div>
    <div class="row" style="margin-bottom:5px">
      <div class="d-inline col-lg-6 col-md-6 col-sm-12" padding="0px">
        <b>Emergency addr.</b>
      </div>
      <div
        class="d-inline col-lg-6 col-md-6 col-sm-12"
        padding="0px"
      >{{this.parent.Emergancyaddress}}</div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    parent: {
      type: Object
    }
  }
};
</script>

<style>
</style>
