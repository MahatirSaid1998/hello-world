<template>
  <div class="container">
    <table class="table table-hover" id="tblScores">
      <tbody>
        <tr>
          <th scope="row">Date</th>
          <td style="text-align: left">{{this.date}}</td>
        </tr>
        <tr>
          <th scope="row">Category</th>
          <td style="text-align: left">{{this.action}}</td>
        </tr>
        <tr>
          <th scope="row">Comment</th>
          <td style="text-align: left">{{this.details}}</td>
        </tr>
      </tbody>
    </table>

    <button type="submit" class="btn btn-primary float-right" @click.prevent="$emit('close')">Cancel</button>
  </div>
</template>

<script>
import * as $ from "jquery";

export default {
  props: ["CommentRecID"],
  data: function() {
    return {
      date: "",
      action: "",
      details: ""
    };
  },

  mounted: function() {
    this.loadComments();
  },
  methods: {
    loadComments: function() {
      var playerID = this.$store.state.selectedPlayer.ID;
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Comment";
      //var select = "$select=id, Firstname,lastname";
      var filter = "$filter=ID eq '" + this.CommentRecID + "'";
      baseUrl += "GetByTitle('" + listName + "')/items?" + filter; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.commentsData(data.d.results);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    commentsData: function(data) {
      //this.date = data[0].Date;
      this.date = this.getJSONDateAsString(data[0].Date, "dd.MM.yyyy");
      this.action = data[0].Category;
      this.details = data[0].Comment;
    },
    getJSONDateAsString: function(jsdatevalue, returnFormat) {
      if ((jsdatevalue == "") | (jsdatevalue == null)) {
        return "";
      }
      return new Date(jsdatevalue).toString(returnFormat);
    }
  }
};
</script>

<style scoped>
.v--modal {
  padding-top: 15px;
  padding-left: 10px;
}
/* #tblScores tr,
#tblScores td,
#tblScores th {
  border: 0 !important;
} */
</style>
