<template>
  <tr>
    <td class="text-center">{{this.rowCounter}}</td>
    <td class="text-left"  style="padding:0; vertical-align: middle ;">
      <a href="#" @click="showCharacterDialogShowMode">{{this.character.CreatedDate}}</a>
    </td>
      <td class="text-left"  style="padding:0; vertical-align: middle ;">
      <a href="#" @click="showCharacterDialogShowMode">{{this.character.Evaluator}}</a>
    </td>

    <td v-if="character.Discipline === '1'" class="bg-success text-center text-white" style="padding:0; width:20px; vertical-align: middle; border-right: 1px solid #dee2e6;">{{character.Discipline}}</td>
    <td v-else-if="character.Discipline === '2'" div class="bg-info text-center text-white" style="padding:0; width:20px; vertical-align: middle; border-right: 1px solid #dee2e6; ">{{character.Discipline}}</td>
    <td v-else-if="character.Discipline === '3'" class="bg-warning text-center text-white" style="padding:0; width:20px; vertical-align: middle; border-right: 1px solid #dee2e6;">{{character.Discipline}}</td>
    <td v-else-if="character.Discipline === '4'" class="bg-danger text-center text-white" style="padding:0; width:20px; vertical-align: middle; border-right: 1px solid #dee2e6;">{{character.Discipline}}</td>

    <td v-if="character.Commitment === '1'" class="bg-success text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Commitment}}</td>
    <td v-else-if="character.Commitment === '2'" div class="bg-info text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Commitment}}</td>
    <td v-else-if="character.Commitment === '3'" class="bg-warning text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Commitment}}</td>
    <td v-else-if="character.Commitment === '4'" class="bg-danger text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Commitment}}</td>

     <td v-if="character.Concentration === '1'" class="bg-success text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Concentration}}</td>
    <td v-else-if="character.Concentration === '2'" div class="bg-info text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Concentration}}</td>
    <td v-else-if="character.Concentration === '3'" class="bg-warning text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Concentration}}</td>
    <td v-else-if="character.Concentration === '4'" class="bg-danger text-center text-white" style="padding:0; width:20px; vertical-align: middle ; border-right: 1px solid #dee2e6;">{{character.Concentration}}</td>
    
    <td class="text-left" v-if="character.trimmedGoal" :title="this.character.Goal">{{this.character.trimmedGoal}} ...</td>
    <td class="text-left" v-else>{{this.character.Goal}} </td>
    
    <td class="text-left"  v-if="character.trimmedMotivation"  :title="this.character.Motivation">{{this.character.trimmedMotivation}} ...</td>
    <td class="text-left" v-else>{{this.character.Motivation}} </td>

   <!--  <td style="padding:5px">{{this.character.Discipline}}</td> 
    <td style="padding:5px">{{this.character.Commitment}}</td>
    <td style="padding:5px">{{this.character.Concentration}}</td>-->
  </tr>
</template>


<script>
import CharacterFormShow from "./CharacterFormShow.vue";
export default {
  props: {
    character: {
      type: Object
    },
    index: {
      type: Number
    }
  },
  components: {
    CharacterFormShow
  },
  computed: {
    rowCounter: function() {
      this.index++;
      return this.index;
    }
  },
  data: function() {
    return {
      counter: 0
    };
  },
  methods: {
    showCharacterDialogShowMode: function() {
      this.$modal.show(
        CharacterFormShow,
        {
          characterRecID: this.character.id
        },
        {
          draggable: true,
          width: 400,
          height: 450
        },
        {
          closed: function(event) {}
        }
      );
    }
  }
};
</script>

<style>
</style>
