import { Store } from 'vuex/types/index';
export declare const store: Store<any>;
