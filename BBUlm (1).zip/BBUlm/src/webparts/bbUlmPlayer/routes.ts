/* import Teams  from './components/BbUlmPlayerWebPart/Teams/Teams.vue';
import TeamInfos  from './components/BbUlmPlayerWebPart/Teams/TeamDetails/TeamInfos.vue';
import { Route } from "vue-router/types/router";
export const routes=[
    {path: '/TeamInfo',component: TeamInfos},
    {path: '/Teams',component: Teams},
]; */