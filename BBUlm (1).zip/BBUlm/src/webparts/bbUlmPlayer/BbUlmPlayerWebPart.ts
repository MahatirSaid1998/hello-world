// Importing Vue.js
import Vue from 'vue';
import {store} from './store/store';



//******************** Router */
/* import Teams  from './components/BbUlmPlayerWebPart/Teams/Teams.vue';
import TeamInfos  from './components/BbUlmPlayerWebPart/Teams/TeamDetails/TeamInfos.vue';
const routes=[
    {path: '/TeamInfo',component: TeamInfos},
    {path: '',component: Teams},
];
import VueRouter from 'vue-router';
//import {routes} from './routes';
Vue.use(VueRouter);
const router  = new VueRouter ({
  routes: routes
});  */
//******************** Router */

import { Version } from '@microsoft/sp-core-library';
import {
  BaseClientSideWebPart,
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { escape } from '@microsoft/sp-lodash-subset';

import * as strings from 'BbUlmPlayerWebPartStrings';
var Date = require('datejs');


// Improting Vue.js SFC
import BbUlmPlayerComponent from './components/BbUlmPlayerWebPart/BbUlmPlayer.vue';

import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


import VModal from 'vue-js-modal';
Vue.use(VModal, { dynamic: true });

import VueAutosuggest from "vue-autosuggest";
Vue.use(VueAutosuggest);

import VueTabs from 'vue-nav-tabs';
import 'vue-nav-tabs/themes/vue-tabs.css';
Vue.use(VueTabs);

import Vuelidate from 'vuelidate';
Vue.use(Vuelidate);


/* import Vuetify from 'vuetify';
import 'vuetify/dist/vuetify.min.css';
Vue.use(Vuetify); */

import VueGoodTablePlugin from 'vue-good-table';
// import the styles 
import 'vue-good-table/dist/vue-good-table.css';
Vue.use(VueGoodTablePlugin);


export interface IBbUlmPlayerWebPartProps {
  description: string;
}


export default class BbUlmPlayerWebPart extends BaseClientSideWebPart<IBbUlmPlayerWebPartProps> {

  public render(): void {
    const id: string = `wp-${this.instanceId}`;
    this.domElement.innerHTML = `<div id="${id}"></div>`;

    let el = new Vue({
      el: `#${id}`,
      store,
      //router,
      render: h => h(BbUlmPlayerComponent, {
        props: {
          description: this.properties.description
        }
      })
    });
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
