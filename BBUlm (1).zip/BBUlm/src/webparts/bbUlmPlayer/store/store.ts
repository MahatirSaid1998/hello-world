import Vue from 'vue';
import Vuex from 'vuex';
import * as $ from "jquery";

import { Store } from 'vuex/types/index';

Vue.use(Vuex);

export const store: Store<any> = new Vuex.Store({
  //  export const store = new Vuex.Store({

  state: {
    players: [],
    //selectedPlayerID: '',
    selectedPlayer: '',
    selectedTeam:'',
    selectedComp:'',
    selectedEvent:'',
    //baseUrl : "/DEV/BBUlm" + "/_api/web/lists/",
    baseUrl : "/sites/Playercard" + "/_api/web/lists/",
    //baseUrlContextinfo: "/DEV/BBUlm" + "/_api/contextinfo",
    baseUrlContextinfo: "/sites/Playercard" + "/_api/contextinfo",
    //baseImageUrl: 'https://camdere.sharepoint.com/DEV/BBUlm',
    baseImageUrl: 'https://basketballulm1.sharepoint.com/sites/Playercard/'

  },
  mutations: {
    FETCH_PLAYERS(state, players) {
      state.players = players;
    }
  },
  actions: {
    fetchPlayers({ commit }, { self }) {

      var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var listName = "Player";
      var select = "$select=id,Name,NameId,IDinformation,Nationality,Telephone,Email,Birthday,Position,Address,Bild,Name/Name";
      var expand = "&$expand=Name";

      baseUrl += "GetByTitle('" + listName + "')/items?"+ select + expand ; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function (data) {
          //alert("success");
          commit("FETCH_PLAYERS", data.d.results);

          self.playersData();
        },
        error: function (xhr) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });



    }
  }
});

/* ,
    getters:{
        doubleIt: state => {
            return state.selectedComponent * 2;
        }
    }, */