﻿<template>
  <div>
    <!-- Players Infos -->
    <div class="row">
      <div class="d-inline col-lg-3 col-md-3 col-sm-3" style="margin-bottom:5px">
        <img :src="this.players.Picture" class="rounded float-left" width="100px" height="130px">
      </div>
      <div class="d-inline col-lg-9 col-md-9 col-sm-9">
        <div class="row">
          <div style="padding-bottom:10px; padding-left:15px;">
            <div style="font-size:1.4em">{{ this.players.Name }}</div>
          </div>
        </div>

        <div class="row">
          <div class="d-inline col-lg-6 col-md-6 col-sm-6">
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">
                <b>Position</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">
                <div>{{ this.players.Position }}</div>
              </div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">
                <b>Nationality</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.players.Nationality }}</div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">
                <b>Birthday</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">
                <div>{{ this.players.Birthday }}</div>
              </div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-3">
                <b>Phone</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.players.Telephone }}</div>
            </div>
          </div>
          <div class="d-inline col-lg-6 col-md-6 col-sm-6" padding="0px">
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6" style="padding-left:0">
                <b>Team</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.team.TeamName }}</div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6" style="padding-left:0">
                <b>ID information</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.players.IDinformation }}</div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6" style="padding-left:0">
                <b>E-Mail</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.players.Email }}</div>
            </div>
            <div class="row">
              <div class="d-inline col-lg-6 col-md-6 col-sm-6" style="padding-left:0">
                <b>Address</b>
              </div>
              <div class="d-inline col-lg-6 col-md-6 col-sm-6">{{ this.players.Address }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <hr>

    <!-- Parents Infos -->
    <div class="row">
      <app-parents v-for="parent in parents" :parent="parent"></app-parents>
    </div>
  </div>
</template> 

<script>
import * as $ from "jquery";
import Parents from "./Details/Parents.vue";
export default {
  components: {
    appParents: Parents
  },
  data: function() {
    return {
      players: [],
      parents: [],
      characters: [],
      selectedArryaIndex: "",
      team: [],
      showInfo: false
    };
  },
  created: function() {
    this.team = this.$store.state.selectedTeam;
    var playerID = this.$store.state.selectedPlayer.ID;
    this.selectedPlayerInfo(playerID);

    /* 
    //loads from store
    this.$store.dispatch("fetchPlayers", { self: this });
    var $this = this;
    //watch for player change at autosearch
    this.$store.watch(
      function(state) {
        return $this.$store.state.selectedPlayer; // could also put a Getter here
      },
      function(newValue, oldValue) {
        //something changed do something
        $this.selectedPlayerInfo(newValue);
        //console.log(oldValue);
        //console.log(newValue);
      },
      //Optional Deep if you need it
      {
        deep: true
      }
    ); */
  },
  methods: {
    selectedPlayerInfo: function(playerID) {
      this.loadSelectedPlayer(playerID);
      this.loadParents(playerID);
    },
    loadSelectedPlayer: function(SelectedPlayerID) {
      var data = this.$store.state.players;
      this.players = [];
      this.players = this.$store.state.selectedPlayer;
    },

    loadParents: function(playerID) {
      //var baseUrl = "/DEV/BBUlm" + "/_api/web/lists/";
      var baseUrl = this.$store.state.baseUrl;
      var listName = "Parent";
      var select =
        "$select=id,ParentName,Parent,Address,Telephone,Email,Emergancyaddress,Gerneralinfo,PlayerName/Name";
      var expand = "&$expand=PlayerName";
      var filter = "&$filter=PlayerNameId eq '" + playerID + "'";
      baseUrl +=
        "GetByTitle('" + listName + "')/items?" + select + expand + filter; //+ select;
      var $this = this;
      $.ajax({
        url: baseUrl,
        type: "GET",
        headers: {
          Accept: "application/json;odata=verbose"
        },
        async: false,
        success: function(data, textStatus, xhr) {
          $this.parentsData(data);
        },
        error: function(xhr, textStatus, errorThrown) {
          alert("error:" + JSON.stringify(xhr));
          $("#start" + "records").html(" [0]");
        }
      });
    },
    parentsData: function(data) {
      this.parents = [];
      var $this = this;
      for (var i = 0; i < data.d.results.length; i++) {
        $this.parents.push({
          id: data.d.results[i].ID,
          ParentName: data.d.results[i].ParentName,
          ParentType: data.d.results[i].Parent,
          Address: data.d.results[i].Address,
          Telephone: data.d.results[i].Telephone,
          Email: data.d.results[i].Email,
          Emergancyaddress: data.d.results[i].Emergancyaddress,
          Gerneralinfo: data.d.results[i].Gerneralinfo
        });
      }
    }
  }
};
</script>

<style>
</style>
