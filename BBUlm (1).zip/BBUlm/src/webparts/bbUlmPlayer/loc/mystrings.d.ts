declare interface IBbUlmPlayerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'BbUlmPlayerWebPartStrings' {
  const strings: IBbUlmPlayerWebPartStrings;
  export = strings;
}
